nota=float(input("Pon el numero de tu nota"))
print("Tu nota es",nota)
curva=nota*0.8+1
print("Tu curva es",curva)