empls = {5:{
    "nombre": "carlos"
    "hrs_trabajadas": 5,
    "vlr_hora": 10
},
7:{
    "nombres": None,
    "hrs_trabajadas": None
    "vlr_hora": None
    },
}

empls[5]["nombre"]
empls[21]["nombre"]= "Javier"

