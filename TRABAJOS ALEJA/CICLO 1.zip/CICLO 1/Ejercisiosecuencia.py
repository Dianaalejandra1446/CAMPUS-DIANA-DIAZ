#Entrada 1
segundos = int(input("125"))
hora = int(input("0"))
minutos =   int(input("2"))
segundos = int (input("5"))
print()

#Entrada 2
segundos = int(input("3725"))

hora = int(input("1"))
minutos = int(input("2"))
segundos = int(input("5"))

