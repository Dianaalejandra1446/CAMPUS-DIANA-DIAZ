altura = float(input("altura: "))
base = float(input("base: "))
area=(base * altura)/2
print("El area es" , "{:,.2f}".format(area))