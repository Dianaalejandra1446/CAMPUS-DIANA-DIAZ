numero1 = 10
numero2 = 1.124568
sNombre = "Oscar"
numero2 = "Daniel"
sw = False
numero2 = numero1 // 5
numero2 = numero2 ** 2 * 3 -2
print(type(sNombre))

# OPERADORES DE CADENA
"""
A continuacion se veran los
 diferentes operadores de cadena
"""

str1 = "Hola"
str2 = "mundo"
str3 =str1 + " " + str2
print(str3)

# Operador Repeticion (*)
str3 = str1 * 3;
print(str3)

# FORMATEO DE CADENAS

# cadenas f-string
print(f"hola ${str2} , {numero2}")

#cadenas con formato
print("Hola %s , %d" % ("mundo",numero2,True))
