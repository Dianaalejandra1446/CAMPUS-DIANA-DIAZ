str1 = "Abrilz"
str2 = "Abrilinico"

#Condicional simple
"""
if str1 < str2:
    print("La cadena 1 es menor a la cadena 2")
print("Fin del codigo")"""

#Condicional doble
"""if str1 < str2:
    print("La cadena 1 es menor que la 2")
else:
    print("La cadena 2 es menor que la cadena 1")

print("Fin del programa")"""

#Condicinal multiple
if str1 == str2:
    print("Ambas cadenas son iguales")
elif str1 < str2:
    print("Cadena1 menor que cadena 2")
else:
    print("Cadena2 es menor que cadena1")

