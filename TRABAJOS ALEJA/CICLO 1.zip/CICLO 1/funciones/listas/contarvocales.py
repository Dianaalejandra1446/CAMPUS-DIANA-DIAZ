"""Se desea realizar un programa en el cual se ingresen N letras del abecedario,las cuales se deben almacenar en una lista.Una vez creada la lista se desea conocer e imprimir la cantidad de a y la cantidad de e y la cantidad de i,la cantidad de o y la cantdiad de u que se encuentre en la lista"""

ListaAbecedario = []
canLetras = [0]

ingresar = input("Ingrese la palabra: ")
